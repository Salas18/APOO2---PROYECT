# APOO2---PROYECT

🎮 Introducción al Proyecto: Huevos a la Fuga
Huevos a la Fuga es un videojuego de plataformas 2D con desplazamiento lateral, desarrollado en Python utilizando la librería Pygame como parte del curso de Programación Orientada a Objetos. El juego tiene como protagonista a un huevo que intenta escapar de una cocina llena de peligros. El jugador deberá controlar al huevo mientras salta, esquiva obstáculos y aprovecha power-ups para sobrevivir y alcanzar la salida en cada nivel.

Este proyecto no solo pone en práctica los fundamentos de la programación orientada a objetos, sino que también demuestra creatividad, trabajo en equipo y aplicación de lógica algorítmica en un entorno interactivo.

Equipo de desarrollo:

Miguel Ángel Salazar Orrego

José Ángel Sánchez Martínez

Luisa Fernanda Espinal Montoya

Zharick Dayana Vasquez Valenzuela
