class EstadoJuego:
    MENU = 0
    INGRESO_NOMBRE = 1
    JUGANDO = 2
    PAUSA = 3
    GAME_OVER = 4
    VICTORIA = 5 